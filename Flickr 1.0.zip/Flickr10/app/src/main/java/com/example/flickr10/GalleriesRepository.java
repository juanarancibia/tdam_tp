package com.example.flickr10;

public class GalleriesRepository {
}
